<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|


Route::get('/', function () {
    return view('welcome');
});
*/
Route::get('/', "App\Http\Controllers\StudentController@index") ;
Route::get('/edit/{id}', "App\Http\Controllers\StudentController@edit") ;
Route::get('/show/{id}', "App\Http\Controllers\StudentController@show") ;
Route::get('/create', "App\Http\Controllers\StudentController@create") ;
Route::post('/store', "App\Http\Controllers\StudentController@store") ;
Route::post('/update/{id}', "App\Http\Controllers\StudentController@update") ;
Route::delete('/delete/{id}', "App\Http\Controllers\StudentController@destroy") ;

Route::get('/tours', "App\Http\Controllers\TourController@indexT") ;
Route::get('/tours/edit/{id}', "App\Http\Controllers\TourController@editT") ;
Route::get('/tours/show/{id}', "App\Http\Controllers\TourController@showT") ;
Route::get('/tours/create', "App\Http\Controllers\TourController@createT") ;
Route::post('/tours/store', "App\Http\Controllers\TourController@storeT") ;
Route::post('/tours/update/{id}', "App\Http\Controllers\TourController@updateT") ;
Route::delete('/tours/delete/{id}', "App\Http\Controllers\TourController@destroyT") ;

#Route::get('/toursAndClients', "App\Http\Controllers\TourController@indexTandC") ;

Route::post('/tours/storeTour"', "App\Http\Controllers\TourController@storeTour") ;