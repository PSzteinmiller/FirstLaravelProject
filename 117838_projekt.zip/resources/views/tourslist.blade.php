
<div class="card mb-3">
  <img src="https://in2english.net/wp-content/uploads/2020/06/travelling-is-fun.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List of tours</h5>
    <p class="card-text">You can find here informations about tours in the system</p>
        <table class="table">
            <thead class="thead-light">
                <tr>
                <th scope="col">name</th>
                <th scope="col">direction</th>
                <th scope="col">time_of_visit</th>
                <th scope="col">price</th>
                <th scope="col">Operations</th>
                
                </tr>
            </thead>
            <tbody>
            @foreach($tours as $tour)
            <tr>
                <td>{{ $tour->name }}</td>
                <td>{{ $tour->direction }}</td>
                <td>{{ $tour->time_of_visit }}</td>
                <td>{{ $tour->price }}</td>
                
                <td>
                    <a href="<?php echo e(url('/tours/edit/'.$tour->id)) ?>" class="btn btn-sm btn-info">Edit</a>
                    <form action = "<?php echo e(url('/tours/delete/'.$tour->id))?>" method="POST" >
                                @csrf
                                @method('delete')
                                <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>

            </tr>
            @endforeach
            </tbody>
        </table>
        
  </div>
</div>


    
