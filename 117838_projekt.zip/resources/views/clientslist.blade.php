
<div class="card mb-3">
  <img src="https://in2english.net/wp-content/uploads/2020/06/travelling-is-fun.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List of clients</h5>
    <p class="card-text">You can find here informations about clients in the system</p>
        <table class="table">
            <thead class="thead-light">

                <tr>
                <th scope="col">CNE</th>
                <th scope="col">First name</th>
                <th scope="col">Second Name</th>
                <th scope="col">Age</th>
                <th scope="col">Phone number</th>
                <th scope="col">tour name</th>
                <th scope="col">Operations</th>
                </tr>

            </thead>
            <tbody>
            @foreach($clients as $client)
            <tr>
                <td>{{ $client->cne }}</td>
                <td>{{ $client->firstName }}</td>
                <td>{{ $client->secondName }}</td>
                <td>{{ $client->age }}</td>
                <td>{{ $client->phoneNumber }}</td>

                <td>
                @foreach($tours as $tour)
                  
                  @if($tour -> client_id == $client -> id)

                  {{ $tour-> name  }} </br>

                  @endif
              
                @endforeach 
                </td>
              
                <td>
                    <a href="<?php echo e(url('/edit/'.$client->id)) ?>" class="btn btn-sm btn-info">Edit</a>
                    <form action = "<?php echo e(url('/delete/'.$client->id))?>" method="POST" >
                                    @csrf
                                    @method('delete')
                                    <button class="btn btn-danger" type="submit">Delete</button>
                        </form>  
                </td>
                
            </tr>
           
            @endforeach 
            </tbody>
        </table>
  </div>
</div>


    
