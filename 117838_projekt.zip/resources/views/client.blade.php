<!doctype html>
<html lang="pl" >
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-dc2NSrAXbAkjrdm9IYrX10fQq9SDG6Vjz7nQVKdKcJl3pC+k37e7qJR5MVSCS+wR" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
  </head>
  <body>
    @include("navbar")

    <div class="row header-container justify-content-center">
        <div class="header">
            <h1>Client managment system</h1>
        </div>
    </div>

    @if($layout == 'index')
        <div class="container-fluid mt-4">
            <div class="container-fluid mt-4">
                <div class="row justify-content-center">
                    <section class="col-md-7">
                        @include("clientslist")
                    </section>
                </div>
            </div>
        </div>

    @elseif($layout == 'create')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col">
                    @include("clientslist")
                </section>
                <section class="col">

                <div class="card mb-3">
                    <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Enter the informations of the new client</h5>
                            <form action = "<?php echo e(url('/store')) ?>" method="post">
                            @csrf
                            <div class="form-group">
                                <label>CNE</label>
                                <input name="cne" type="text" class="form-control" placeholder="Enter cne">
                            </div>
                            <div class="form-group">
                                <label>First Name</label>
                                <input name="firstName" type="text" class="form-control" placeholder="Enter first name">
                            </div>
                            <div class="form-group">
                                <label>Second Name</label>
                                <input name="secondName" type="text" class="form-control" placeholder="Enter second name">
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <input name="age" type="text" class="form-control" placeholder="Enter age">
                            </div>
                            <div class="form-group">
                                <label>Phone number</label>
                                <input name="phoneNumber" type="text" class="form-control" placeholder="Enter phone number">
                            </div>
                            
                            
                            <input type="submit" class="btn btn-info" value="Save">
                            <input type="reset" class="btn btn-warning" value="Reset">

                        </form>
                       
                    </div> 
                    @if($errors->any())
                        <div class="w-4/8 m-auto text-center">
                            @foreach ($errors->all() as $error)
                            <li class=".text-danger">
                                {{ $error }}
                            </li>
                            @endforeach
                        </div>
                    @endif
                </div>
                            
                    
                </section>
            </div>
        </div>

    @elseif($layout == 'show')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col">
                    @include("clientslist")
                </section>
                <section class="col"></section>
            </div>
        </div>

    @elseif($layout == 'edit')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col -md-7">
                    @include("clientslist")
                </section>
                <section class="col -md-5">

                <div class="card mb-3">
                    <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Update informations</h5>
                            <form action = "<?php echo e(url('/update/'.$client->id)) ?>" method="post">
                            @csrf
                            <div class="form-group">
                                <label>CNE</label>
                                <input value="{{ $client->cne }}"name="cne" type="text" class="form-control" placeholder="Enter cne">
                            </div>
                            <div class="form-group">
                                <label>First Name</label>
                                <input value="{{ $client->firstName }}" name="firstName" type="text" class="form-control" placeholder="Enter first name">
                            </div>
                            <div class="form-group">
                                <label>Second Name</label>
                                <input value="{{ $client->secondName }}" name="secondName" type="text" class="form-control" placeholder="Enter second name">
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <input value="{{ $client->age }}" name="age" type="text" class="form-control" placeholder="Enter age">
                            </div>
                            <div class="form-group">
                                <label>Phone number</label>
                                <input value="{{ $client->phoneNumber }}" name="phoneNumber" type="text" class="form-control" placeholder="Enter phone number">
                            </div>
                            <input type="submit" class="btn btn-info" value="Update">
                            <input type="reset" class="btn btn-warning" value="Reset">

                        </form>
                    </div>
                    @if($errors->any())
                        <div class="w-4/8 m-auto text-center">
                            @foreach ($errors->all() as $error)
                            <li class=".text-danger">
                                {{ $error }}
                            </li>
                            @endforeach
                        </div>
                    @endif
                </div>

                
                </section>
            </div>
        </div>
        @elseif($layout == 'delete')
            <div class="container-fluid mt-4">
                <div class="row">
                    <section class="col -md-7">
                        @include("clientslist")
                    </section>
                    <section class="col -md-5">

                    <div class="card mb-3">
                        <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Delete informations</h5>
                                <form action = "<?php echo e(url('/delete/'.$client->id)) ?>" method="POST">
                                @csrf
                                <div class="form-group">
                                    <label>CNE</label>
                                    <input value="{{ $client->cne }}"name="cne" type="text" class="form-control" placeholder="Enter cne">
                                </div>
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input value="{{ $client->firstName }}" name="firstName" type="text" class="form-control" placeholder="Enter first name">
                                </div>
                                <div class="form-group">
                                    <label>Second Name</label>
                                    <input value="{{ $client->secondName }}" name="secondName" type="text" class="form-control" placeholder="Enter second name">
                                </div>
                                <div class="form-group">
                                    <label>Age</label>
                                    <input value="{{ $client->age }}" name="age" type="text" class="form-control" placeholder="Enter age">
                                </div>
                                <div class="form-group">
                                    <label>Phone number</label>
                                    <input value="{{ $client->phoneNumber }}" name="phoneNumber" type="text" class="form-control" placeholder="Enter phone number">
                                </div>
                                <input type="submit" class="btn btn-warning" value="Delete">
                                <input type="reset" class="btn btn-info" value="Reset">

                            </form>
                        </div>
                    </div>

                    
                    </section>
                </div>
            </div>
    @endif

    <footer>
                        <form action="<?php echo e(url('/tours/storeTour')) ?>" method="POST">
                            <div class="form-group">
                                <label>Client_id</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option selected></option>
                                    @foreach ($clients as $client)
                                    <option value="{{ $client->cne }}">{{ $client->cne }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>tour_name</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option selected></option>
                                    @foreach ($tours as $tour)
                                    <option value="{{ $tour->name }}">{{ $tour->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <input type="submit" class="btn btn-info" value="Save">
                        </form>

                        
    </footer>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>
    -->
  </body>
</html>