<!doctype html>
<html lang="pl">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-dc2NSrAXbAkjrdm9IYrX10fQq9SDG6Vjz7nQVKdKcJl3pC+k37e7qJR5MVSCS+wR" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
  </head>
  <body>
    @include("navbar")

    <div class="row header-container justify-content-center">
        <div class="header">
            <h1>Client managment system</h1>
        </div>
    </div>

    @if($layout == 'indexT')
        <div class="container-fluid mt-4">
            <div class="container-fluid mt-4">
                <div class="row justify-content-center">
                    <section class="col-md-7">
                        @include("tourslist")
                    </section>
                </div>
            </div>
        </div>

    @elseif($layout == 'createT')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col">
                    @include("tourslist")
                </section>
                <section class="col">

                <div class="card mb-3">
                    <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Enter the informations of the new tour</h5>
                            <form action = "<?php echo e(url('/tours/store')) ?>" method="post">
                            @csrf
                            <div class="form-group">
                                <label>name</label>
                                <input name="name"  type="text" class="form-control" placeholder="Enter name">
                            </div>
                            <div class="form-group">
                                <label>direction</label>
                                <input name="direction" type="text" class="form-control" placeholder="Enter direction">
                            </div>
                            <div class="form-group">
                                <label>time_of_visit</label>
                                <input name="time_of_visit" type="text" class="form-control" placeholder="Enter time_of_visit">
                            </div>
                            <div class="form-group">
                                <label>price</label>
                                <input name="price" type="text" class="form-control" placeholder="Enter price">
                            </div>
                            
                            <input type="submit" class="btn btn-info" value="Save">
                            <input type="reset" class="btn btn-warning" value="Reset">

                        </form>
                    </div>
                    @if($errors->any())
                        <div class="w-4/8 m-auto text-center">
                            @foreach ($errors->all() as $error)
                            <li class=".text-danger">
                                {{ $error }}
                            </li>
                            @endforeach
                        </div>
                    @endif
                </div>

                    
                </section>
            </div>
        </div>

    @elseif($layout == 'showT')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col">
                    @include("tourslist")
                </section>
                <section class="col"></section>
            </div>
        </div>

    @elseif($layout == 'editT')
        <div class="container-fluid mt-4">
            <div class="row">
                <section class="col -md-7">
                    @include("tourslist")
                </section>
                <section class="col -md-5">

                <div class="card mb-3">
                    <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Update informations</h5>
                            <form action = "<?php echo e(url('/tours/update/'.$tour->id)) ?>" method="post">
                            @csrf
                            <div class="form-group">
                                <label>name</label>
                                <input name="name" value="{{ $tour->name }}" type="text" class="form-control" placeholder="Enter name">
                            </div>
                            <div class="form-group">
                                <label>direction</label>
                                <input name="direction" value="{{ $tour->direction }}"type="text" class="form-control" placeholder="Enter direction">
                            </div>
                            <div class="form-group">
                                <label>time_of_visit</label>
                                <input name="time_of_visit" value="{{ $tour->time_of_visit }}"type="text" class="form-control" placeholder="Enter time_of_visit">
                            </div>
                            <div class="form-group">
                                <label>price</label>
                                <input name="price" value="{{ $tour->price }}"type="text" class="form-control" placeholder="Enter price">
                            </div>

                            <input type="submit" class="btn btn-info" value="Update">
                            <input type="reset" class="btn btn-warning" value="Reset">

                        </form>
                    </div>
                    @if($errors->any())
                        <div class="w-4/8 m-auto text-center">
                            @foreach ($errors->all() as $error)
                            <li class=".text-danger">
                                {{ $error }}
                            </li>
                            @endforeach
                        </div>
                    @endif
                </div>

                
                </section>
            </div>
        </div>
        @elseif($layout == 'deleteT')
            <div class="container-fluid mt-4">
                <div class="row">
                    <section class="col -md-7">
                        @include("tourslist")
                    </section>
                    <section class="col -md-5">

                    <div class="card mb-3">
                        <img src="https://content3.jdmagicbox.com/comp/def_content/domestic-tour-packages/shutterstock-222508168-domestic-tour-packages-8-5iued.jpg?clr=4d4d1a" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Delete informations</h5>
                                <form action = "<?php echo e(url('/tours/delete/'.$tour->id)) ?>" method="POST">
                                @csrf
                               <div class="form-group">
                                <label>name</label>
                                <input name="name" type="text" class="form-control" placeholder="Enter name">
                            </div>
                            <div class="form-group">
                                <label>direction</label>
                                <input name="firstName" type="text" class="form-control" placeholder="Enter direction">
                            </div>
                            <div class="form-group">
                                <label>time_of_visit</label>
                                <input name="time_of_visit" type="text" class="form-control" placeholder="Enter time_of_visit">
                            </div>
                            <div class="form-group">
                                <label>price</label>
                                <input name="price" type="text" class="form-control" placeholder="Enter price">
                            </div>
                                <input type="submit" class="btn btn-warning" value="Delete">
                                <input type="reset" class="btn btn-info" value="Reset">

                            </form>
                        </div>
                    </div>

                    
                    </section>
                </div>
            </div>
    @endif

    <footer></footer>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>
    -->
  </body>
</html> 