<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
    // protected $fillable = ['cne'];
        protected $table = 'clients';
    // public function users()
    // {
    // return $this->belongsToMany(Client::class);
    // }
    public function tours(){
        return $this->belongsToMany(Tour::class)
                //    ->withPivot('name')
               //     ->withTimestamps()
                    ;
    }
}
