<?php

namespace App\Http\Controllers;

use App\Models\Tour;
use App\Models\Client;
use Illuminate\Http\Request;

class TourController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexT()
    {
        $clients = Client::all() ;
        $tours = Tour::all();  
        return view('tour', compact('tours','clients'),['layout'=>'indexT']) ;
    }
    //przed zmiana
    // public function indexT()
    // {
    //     $tours = Tour::all() ;
    //     return view('tour', ['tours'=>$tours,'layout'=>'indexT']) ;
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createT()
    {
        $clients = Tour::all(); 
        $tours = Tour::all() ;
        return view('tour',compact('tours','clients'),['layout'=>'createT']); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeT(Request $request)
    {
        $request->validate([
            'name'=>'required|unique:tours',
            'direction'=>'required|string',
            'time_of_visit'=>'required|string',
            'price'=>'required|numeric'         
        ]);    

        $tour = new Tour() ;

        $tour->name = $request->input('name') ;
        $tour->direction = $request->input('direction') ;
        $tour->time_of_visit = $request->input('time_of_visit') ;
        $tour->price = $request->input('price') ;
        
        $tour->save() ;
        return redirect('/') ;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showT($id)
    {
        $tour = Tour::find($id) ;
        $tours = Tour::all() ;
        return view('tour',['tours'=>$tours,'tour'=>$tour,'layout'=>'showT']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editT($id)
    {   
        $clients = Client::all();
        $tour = Tour::find($id) ;
        $tours = Tour::all() ;
        return view('tour',compact('tour','tours','clients'),['layout'=>'editT']);
    }
    // public function edit($id)
    // {
    //     $tours = Tour::all() ;
    //     $client = Client::find($id) ;
    //     $clients = Client::all() ;
    //     return view('client',compact('client','clients','tours'),['layout'=>'edit']);
    
    // }
    //przed zmiana
    // public function editT($id)
    // {
    //     $tour = Tour::find($id) ;
    //     $tours = Tour::all() ;
    //     return view('tour',['tours'=>$tours,'tour'=>$tour,'layout'=>'editT']);
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateT(Request $request, $id)
    {
        $tour = Tour::find($id) ;

        $tour->name = $request->input('name') ;
        $tour->direction = $request->input('direction') ;
        $tour->time_of_visit = $request->input('time_of_visit') ;
        $tour->price = $request->input('price') ;

        $tour->save();
        return redirect('/') ;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroyT($id)
    {
        $tour = Tour::find($id) ;
        $tour->delete();
        return redirect('/');
    }
}
