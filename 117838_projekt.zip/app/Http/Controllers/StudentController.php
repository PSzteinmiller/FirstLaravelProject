<?php

namespace App\Http\Controllers;

use App\Models\Tour;
use App\Models\Client;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
        $clients = Client::all() ;
        $tours = Tour::all() ;  
        return view('client', compact('tours','clients'),['layout'=>'index']) ;
    }
            //przed zmiana
    //         public function index()
    // {
    //     $clients = Client::all() ;
    //     return view('client', ['clients'=>$clients,'layout'=>'index']) ;
    // } 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $clients = Client::all() ;
        $tours = Tour::all(); 
        return view('client',compact('tours','clients'),['layout'=>'create']); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'cne'=>'required|unique:clients',
            'firstName'=>'required|string',
            'secondName'=>'required|string',
            'age'=>'required|numeric',
            'phoneNumber'=>'required|numeric|min:9'         
        ]);

        $client = new Client() ;

        $client->cne = $request->input('cne') ;
        $client->firstName = $request->input('firstName') ;
        $client->secondName = $request->input('secondName') ;
        $client->age = $request->input('age') ;
        $client->phoneNumber = $request->input('phoneNumber') ;
        
        $client->save() ;
        return redirect('/') ;
    }
    public function storeTour(Request $request,Client $id,Tour $client_id)
    {
        $client = Client::find($id);
        $tour = Tour::find($client_id);

        $client_id = $client;
        
        $tour->save() ;
        return redirect('/') ;
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $client = Client::find($id) ;
        $clients = Client::all() ;
        return view('client',['clients'=>$clients,'client'=>$client,'layout'=>'show']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tours = Tour::all() ;
        $client = Client::find($id) ;
        $clients = Client::all() ;
        return view('client',compact('client','clients','tours'),['layout'=>'edit']);
    
    }
    // public function editT($id)
    // {
    //     $clients = Client::all() ;
    //     $tour = Tour::find($id) ;
    //     $tours = Tour::all() ;
    //     return view('tour',['tours'=>$tours,'tour'=>$tour,'layout'=>'edit']) ;
    // }
    /**
     * Update the specified resource in storage.
     *                                                     ->nullable()->change()
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $client = Client::find($id) ;

        $client->cne = $request->input('cne') ;
        $client->firstName = $request->input('firstName') ;
        $client->secondName = $request->input('secondName') ;
        $client->age = $request->input('age') ;
        $client->phoneNumber = $request->input('phoneNumber') ;

        $client->save();
        return redirect('/') ;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $client = Client::find($id) ;
        $client->delete();
        return redirect('/');
    }
}
